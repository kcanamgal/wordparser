package com.example.demo.util;

public class EncodingHelper {

    private EncodingHelper() { }

//    public static String SHA256Encoding()
}
